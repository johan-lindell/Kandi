aaltologo.sty -- A LaTeX package for creating Aalto University logos

See the accompanying documentation in aaltologo.pdf for a user manual. Read the file
LICENSES.txt for publication licenses of the files aaltologo.sty and aaltologo.pdf.
The publication licenses are also given in the documentation.

For installation, move/copy aaltologo.sty to a location where LaTeX can find it.

Enjoy creating Aalto University logos.
